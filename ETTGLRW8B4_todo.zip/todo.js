let todoItemsContainerEle = document.getElementById("todoItemsContainer");
let addButEle = document.getElementById('addButton');
let saveButton = document.getElementById('saveBtn');

function getTodo() {
    let string = localStorage.getItem('todo');
    let obj = JSON.parse(string);
    if (string === null) {
        return [];
    } else {
        return obj;
    }
}
let todo = getTodo();

saveButton.onclick = function() {
    localStorage.setItem('todo', JSON.stringify(todo));
}

function onTodoStatusChange(checkboxId, labelId, todoId) {
    let labelEle = document.getElementById(labelId);
    labelEle.classList.toggle('checked');

    let index = todo.findIndex(function(item) {
        let itemId = 'todo' + item.uniqueNo;
        if (itemId === todoId) {
            return true;
        } else {
            return false;
        }
    });
    let itemObj = todo[index];
    if (itemObj.isChecked === true) {
        itemObj.isChecked = false;
    } else {
        itemObj.isChecked = true;
    }
}

function onDeletetodo(todoId) {
    let delEle = document.getElementById(todoId);
    todoItemsContainerEle.removeChild(delEle);
    let delItemIndex = todo.findIndex(function(item) {
        let deltodoId = 'todo' + item.uniqueNo;
        if (deltodoId === todoId) {
            return true;
        } else {
            return false;
        }
    });
    todo.splice(delItemIndex, 1);
}

function addItem(todo) {

    let checkboxId = "checkbox" + todo.uniqueNo;
    let labelId = "label" + todo.uniqueNo;
    let todoId = "todo" + todo.uniqueNo;

    let todoItem = document.createElement('li');
    todoItem.classList.add("todo-item-container", "d-flex", "flex-row");
    todoItem.id = todoId;
    todoItemsContainerEle.appendChild(todoItem);

    let item = document.createElement('input');
    item.type = "checkbox";
    item.id = checkboxId;
    item.checked = todo.isChecked;
    item.classList.add("checkbox-input");
    item.onclick = function() {
        onTodoStatusChange(checkboxId, labelId, todoId);
    };
    todoItem.appendChild(item);

    let labelCont = document.createElement('div');
    labelCont.classList.add("label-container", "d-flex", "flex-row");
    todoItem.appendChild(labelCont);

    let labelItem = document.createElement('label');
    labelItem.htmlFor = checkboxId;
    labelItem.id = labelId;
    labelItem.classList.add("checkbox-label");
    labelItem.textContent = todo.text;
    labelCont.appendChild(labelItem);
    if (todo.isChecked === true) {
        labelItem.classList.add('checked');
    }

    let deleteCont = document.createElement('div');
    deleteCont.classList.add("delete-icon-container");
    labelCont.appendChild(deleteCont);

    let delIcon = document.createElement('i');
    delIcon.classList.add("far", "fa-trash-alt", "delete-icon");
    deleteCont.appendChild(delIcon);
    delIcon.onclick = function() {
        onDeletetodo(todoId);
    };
}
for (let item of todo) {
    addItem(item);
}

let l = todo.length;

function onAddTodo() {
    l = l + 1;
    let inputEle = document.getElementById('todoUserInput');
    let inputVal = inputEle.value;
    if (inputVal === "") {
        alert('Enter valid input');
        return;
    }
    let newTodo = {
        text: inputVal,
        uniqueNo: l,
        isChecked: false
    };
    addItem(newTodo);
    todo.push(newTodo);
    inputEle.value = "";
}

addButEle.onclick = function() {
    onAddTodo();
};